package com.shell.apigee.poc;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.util.EntityUtils;

public class ApigeeConnector {
	private String host;
	private String userName;
	private String protocol;
	private String password;
	private String apigeeKey;
	
	public ApigeeConnector(String host, String protocol, String userName, String password, String apigeeKey){
		this.host=host;
		this.userName=userName;
		this.protocol=protocol;
		this.password=password;
		this.apigeeKey=apigeeKey;
	}
	
	private String getEncodedAuthString(){
		String authString = this.userName + ":" + this.password;
		byte[] authEncBytes = Base64.encodeBase64(authString.getBytes());
		String authStringEnc = new String(authEncBytes);
		return authStringEnc;
	}
	
	private String generateUrl(String url, String apiKey){
		StringBuilder sb = new StringBuilder();
		sb.append(this.protocol);
		sb.append("://");
		sb.append(this.host+"/");
		sb.append(url+"?");
		sb.append("apikey="+apiKey);
		return sb.toString();
	}
	
	public Map<String, String> post(String url, String xmlData){
		HttpPost httpPost = new HttpPost(generateUrl(url, this.apigeeKey));
		HttpHost proxy = new HttpHost("nbproxy-hon.asia-pac.shell.com", 8080, "http"); //This is required only if proxy is needed to connect the apigee host
		Map<String, String> respMap = new HashMap<String, String>();
		httpPost.setHeader(new BasicHeader("Accept", ContentType.APPLICATION_XML.getMimeType()));
		httpPost.setHeader("Authorization", "Basic " + getEncodedAuthString());
		
		StringEntity requestEntity = new StringEntity(xmlData, ContentType.APPLICATION_XML);
		httpPost.setEntity(requestEntity);
		
		int timeout = 60;
		RequestConfig config = RequestConfig.custom()
		  .setConnectTimeout(timeout * 1000)
		  .setConnectionRequestTimeout(timeout * 1000)
		  .setSocketTimeout(timeout * 1000)
		  .setProxy(proxy) //This is required only if proxy is needed to connect the apigee host
		  .build();
		System.out.println(httpPost.getURI().toString());
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		BasicHttpContext httpContext = new BasicHttpContext();
		HttpResponse response = null;
		String finalResponse = null;

		try {
			response = httpClient.execute(httpPost, httpContext);
			HttpEntity responseEntity = response.getEntity();
			finalResponse = EntityUtils.toString(responseEntity, "utf-8");
			respMap.put("StatusCode", ""+response.getStatusLine().getStatusCode());
			respMap.put("ResponseContent", finalResponse);
			//System.out.println(finalResponse);
		}catch(Exception e){
			e.printStackTrace();
		}
		return respMap;
	}
	
	/*public static void main(String[] s){
		ApigeeConnector ac = new ApigeeConnector("api-dev.shell.com", "https", "userdev", "pwd123");
		ac.post("ds-globalcommercial-markethub-doctype/webapi/da/v1/doctype/token", "A4uBxDbVrexOKkcuNfNpx7p4o8Gn42N9", "<Request><ProviderKey>Pg5UUVnr</ProviderKey></Request>");
	}*/
}
