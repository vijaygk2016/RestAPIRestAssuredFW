package com.shell.apigee.poc;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;


public class EncryptUtil {

	public static final String REQUEST_DATA_ENC_PASSWORD = "W0r1dP67$s&d2BuA";

	public static String encrypt(String strClearText){
		String strData = null;

		try {
			SecretKeySpec skeyspec = new SecretKeySpec(REQUEST_DATA_ENC_PASSWORD.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, skeyspec,new IvParameterSpec(new byte[16]));
			byte[] encrypted = cipher.doFinal(strClearText.getBytes());
			strData = Base64.encodeBase64String(encrypted);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return strData;
	}
	
	public static String decrypt(String strEncrypted) {
		String strData = null;

		try {
			SecretKeySpec skeyspec = new SecretKeySpec(REQUEST_DATA_ENC_PASSWORD.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, skeyspec,new IvParameterSpec(new byte[16]));
			byte[] decrypted = cipher.doFinal((Base64.decodeBase64(strEncrypted)));
			strData = new String(decrypted);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return strData;
	}
	
	public static void main(String[] args){
		
				
		System.out.println(encrypt("\"documentType\":\"loyaltyMailbox\",\"outputFormat\":\"txt\",\"soldTo\":\"12326490\",\"FromDate\":\"20190325\",\"toDate\":\"20190325\"}}]"));
		//System.out.println(encrypt("\"documentType\":\"BOL\",\"outputFormat\":\"xml\",\"soldTo\":\"12316886\",\"FromDate\":\"20190415\",\"toDate\":\"20190415\"}}]"));
		//System.out.println(decrypt("16x1q4eU0j18VskvHNEUNNUDRxgWqptRH0VqrjfXTpFnnuvB9/n1+Mz10r8XpfgnAZM08KzBjhIfKcs0eDM3gSqFr5pg8hh0j6ycssxZfb/YUJm1E03Aq/bJP95H7E2SNLrjrJfx0ctkuNZlT3Lax50UNwSN4edfZuL5GWgOqpo"));

		//update
//String sampleJson = "[{\"ProviderKey\":\"1REi2av2\",\"ApigeeKey\":\"A4uBxDbVrexOKkcuNfNpx7p4o8Gn42M2\", \"Token\" :\"B2o5BXdXERZLz+P9uqUw11UM1xA/eRnWkkmB4J/8ZlI=\", \"editFlag\": \"true\",\"fuelRequestId\":\"137890\",\"bookedTimeStamp\":\"18-03-2019 10:011\",\"aircraftType\":\"GLF4\",\"flightNumber\":\"102A\",\"airportName\":\"London-Gatwick (Itp)\",\"apron\":\"London Gatwick Airport\" ,\"arrivalDate\":\"21-03-2019 00:00\",\"arrivalTime\": \"20-03-2019 05:25\",\"departureDate\":\"22-03-2019 09:00\",\"departureTime\": \"22-03-2019 09:25\",\"userVolume\":\"20000+\",\"userUOM\":\"UGL\",\"additionalText\":\"L to UGL updated\",\"username\":\"av_ehubuser\",\"origin\": \"Belgium-oo\",\"nextDestination\": \"EGMC\",\"finalDestination\": \"KBGR\",\"operatorname\": \"CLAY LACY AVIATION, INC.\",\"material\":{\"materialCode\":\"000000000400000049\",\"productTxtFR\":\"Jet A-1 / F-35\"},\"opsUserID\":\"airpotops_1\",\"frqhistory\":{\"activityText\":\"edited\",\"activityStatus\":\"Pending\",\"reasonForUpdate\":\"origin change\"},\"location\":{\"iata\":\"LGW\",\"icao\":\"EGKK\"},\"shipTo\":{\"shipToCode\":\"0010342111\",\"shipToText\":\"0010342111\"}, \"oldShipto\":\"0010342111\",\"card\":{\"cardIdNumber\":\"840012300001\",\"tailNumber\":\"A7-AGB\"}}]";
		
		//create
	//String sampleJson = "[{\"ProviderKey\": \"1REi2av2\",\"ApigeeKey\": \"A4uBxDbVrexOKkcuNfNpx7p4o8Gn42N9\",\"Token\": \"R3KN6L/Y1mzfWVhX/uuVw6+kaF6mo5/qF7jXBfippZU=\",\"editFlag\": \"false\",\"aircraftType\": \"Airbus\",\"flightNumber\": \"101\",\"airportName\": \"London-Gatwick (Itp)\",\"apron\": \"LONDON GATWICK AIRPORT\",\"arrivalDate\": \"20-03-2019 12:00\",\"arrivalTime\": \"20-03-2019 12:00\",\"departureDate\": \"21-03-2019 12:00\",\"departureTime\": \"21-03-2019 12:00\",\"userVolume\": \"0 - 1,000\",\"userUOM\": \"L\",\"additionalText\": \"Gatwick request test\",\"username\": \"avcustomer_2\",\"origin\": \"Australia-VH\",\"nextDestination\": \"Azerbaijan-4K\",\"finalDestination\": \"Belgium-oo\",\"operatorname\": \"CLAY LACY AVIATION, INC.\",\"material\":{\"materialCode\": \"000000000400000049\",\"productTxtFR\": \"AVTUR\"},\"location\": {\"iata\": \"LGW\",\"icao\": \"EGKK\"},\"shipTo\":{\"shipToCode\": \"0010210527\",\"shipToText\": \"0010210527\"},\"card\": {\"cardIdNumber\": \"550010530100\",\"tailNumber\": \"A7-AEH\"},\"activityStatus\": \"Pending\",\"reason\": \"\"}]";
		//String sampleJson = "[{\"ProviderKey\": \"1REi2av2\",\"ApigeeKey\": \"A4uBxDbVrexOKkcuNfNpx7p4o8Gn42N9\",\"Token\": \"R3KN6L/Y1mzfWVhX/uuVw6+kaF6mo5/qF7jXBfippZU=\",\"editFlag\": \"false\",\"aircraftType\": \"Airbus\",\"flightNumber\": \"111\",\"airportName\": \"London Gatwick(Itp)\",\"apron\": \"\",\"arrivalDate\": \"18-03-2019 12:00\",\"arrivalTime\": \"18-03-2019 12:00\",\"departureDate\": \"20-03-2019 12:00\",\"departureTime\": \"20-03-2019 12:00\",\"userVolume\": \"0 - 1,000\",\"userUOM\": \"L\",\"additionalText\": \"UV air request!!\",\"username\": \"userdev\",\"origin\": \"Malaysia-9M\",\"nextDestination\": \"Maldives-8Q\",\"finalDestination\": \"Malta-9H\",\"operatorname\": \"Test operator \",\"material\":{\"materialCode\": \"000000000400000049\",\"productTxtFR\": \"AVTUR\"},\"location\": {\"iata\": \"AAL\",\"icao\": \"EKYT\"},\"shipTo\":{\"shipToCode\": \"0010399489\",\"shipToText\": \"0010399489\"},\"card\": {\"cardIdNumber\": \"840012300001\",\"tailNumber\": \"9M-MKA\"},\"activityStatus\": \"Pending\",\"reason\": \"\"}]";

		//AirportRequestJson
	//String sampleJson = "[{\"ProviderKey\": \"1REi2av2\",\"ApigeeKey\": \"A4uBxDbVrexOKkcuNfNpx7p4o8Gn42M2\",\"Token\": \"B2o5BXdXERZLz+P9uqUw11UM1xA/eRnWkkmB4J/8ZlI:\",\"requestType\" : \"airportInfo\"}]";
		
		//FuelRequestJSON
		//String sampleJson = "[{\"ProviderKey\": \"1REi2av2\",\"ApigeeKey\": \"A4uBxDbVrexOKkcuNfNpx7p4o8Gn42M2\",\"Token\": \"B2o5BXdXERZLz+P9uqUw11UM1xA/eRnWkkmB4J/8ZlI:\",\"fuelRequestId\":\"137792\",\"requestType\" : \"fuelrequeststatus\"}]";


		//String encryptedString = encrypt(sampleJson);
		//System.out.println("Encrypted String****" + encryptedString);
		//String decryptedString =decrypt("LKB0jJ/whiXrWM1cEtgIwZmqoPPzXlmF/1rP5/3nHxVcc4aUFl4WS9LZ7tjfjd2TuwvJO3ehOjmzZ/KPSQ3L9MWHfMab8AsgRIVlSX354TH873wyTXd1bBFi7oeARkZEFCxUoSS+XNfj9ueiGxiLjecWByY+GjC1k73x+Q4yuMLLEvP9EbL5jcSSgrKvU0B3h/tswPOteWYcl9MNAld3EVY/BTyxxDNSpQfgH9Tw52a9ANh/X0T+rpCTp4dXR+WNjWx0pQ65dDGqXQ8q6xMEoCYRI1fR/Yze7mfkVjqFaOvTKseJ6XGL6GbMtn+6Habf3f15dzipiW1tuUNMaC7l4BPYPGbHmK0O+Xc8/Z54YQ/SQc/DhPcJwxs9zgCIQDUzt2BsDuOoAyZUd67AMtTcv8DOyTGJ8YS88FQkb/rf+8itQ3ObnvPT1SzNVt0oTe+pd3U6x13gOF9750WzcrfsjBIbeshmDKI0HKVWrHyyGBaZkZuLXt4lzi2Yj1n6PAMDLXJl4rvr6h9rjE64Kz8/hXpZ1opUeteQfKRkT97RPlM9rF7q3InAjJzilMBT8ojMOynCvwSP/R+5SaL4BMXCtXFc/uVSdxOVVpGL76RjaZ1GIVhhGNeHMLPwBpVEE4t/JzrRjf4+dXekclweD3YayS0C4ikSRKx4IGh023B5T6ONxlTuphWU9MVyCfSYkQBZXICUwaLXG6XaYjNg3pIzLwVn2cXvN8KJfR4GOtnxsOmuZeEX7Kywb9XssznrkXkc/y+Pjs7UoFpRQT7+6KrxKdgZbXyZwtBXUMHJkQseXI3+qGEa8l/5zJVRj1Iw2dO+jB1mpKmVCCBLexCizuZFGX2G51BiYkkuUIdYkotqZK8gIuemRMQcxvm3K+EWq/g5w8nAmHjbk0J2cuzq7Ce/zGOZfx2XqUJwDtkas5wdxvOTUxI5/C7+Dx2Fsi1MPHYBDD6Ip4mQFT8m2Z8XpGnlhMzGnYVbxU5W3yjsneCJz1F69VLLn43+GWGDUtbBrEgCd8wQyedhHql22sK1ZCbWDEoyDoLkshNM8j6vpxeU3AuRn9WuCwCVXlXhzbxLJgqJqTeQ0J9CBc6XTetZN0h9iGFijyRf1CXEsDeEEFSbIl3Irm3nOpJhakhkJRYtvwMA20LJkZO/rVHtHYjBM8sd0dXo8BHm2l/me4vAv2t4L6j/6g6wWLYuhdGLs698cf0dliwsVGVY0adaHzV/Kg3zdHKCBsQ9pkF6lO3D72vZyCMmz7vCQdW71FBLV87mF3iYgrIthmpku1EH4GWFOQ19YSN44TQy572tgNb1cwldbn4HnU4NFmkMw/3MMIoEmDJDeOc1VrRjnGQOEjYth+PzNN0/X4L7GRhY2tELOOVijp5IWFyJU+I0WP3npJ/bTlYypn6DmNKnv5w1mXmKfkeF6cm4XXLu9ZouyACorPzv1dKFKvMbQwYZawzxxWwkhUvKKMFK7LnHzwV29PMSolDDjzPAzjutImcdwjl6bDjf3j7Tl/o2pfbYdej5neqNPnwkhGrsdYl5ea0SGOsKXruoMvmUAXJ5LkCRW0GJV77cL+b0AtJw9Qjog5TB1rFTp1iVpm6eEODuqg5VJRwcOx9wdN6af5GwsmLZ/RX1KE+OWEoBafdentC2nCwg3Wn4tOvd");
		//System.out.println("After Decryption JSON****" +decryptedString);
	}

	private static char[] encrypt() {
		// TODO Auto-generated method stub
		return null;
	}
}
