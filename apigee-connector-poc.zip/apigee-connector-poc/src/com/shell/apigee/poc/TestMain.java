package com.shell.apigee.poc;

import java.util.Map;

public class TestMain {

	public static void main(String[] args) {
		TestAPI api = new TestAPI();
		//Map<String, String> map = api.getDocument("JIFZl7gO","creditCardMailbox","xml","12589915",null,"20180404","prod");
		//  Map<String, String> map = api.getDocument("JIFZl7gO","invoice","xml","12589915",null,"20190322","prod");
		//Map<String, String> map = api.getDocument("JIFZl7gO","bol","xml","12589915",null,"20190322","prod");
		
		//Map<String, String> map = api.getDocument("VUiyYclX","invoice","xml","12310504",null,"20190708","perf");
		Map<String, String> map = api.getDocument("JIFZl7gO","invoice","txt","12334454",null,"20190704","prod");
		




		//Map<String, String> map = api.getDocument("JIFZl7gO","contractprice","csv","12589915",null,"20190322","prod");
	// Map<String, String> map = api.getDocument("JIFZl7gO","rackprice","csv","12314328",null,"20190321","prod");
	//Map<String, String> map = api.getDocument("VUiyYclX","rackprice","csv","12314328",null,"201905022","perf");

		//Map<String, String> map = api.getDocument("VUiyYclX","loyaltyMailbox","txt","12326490",null,"20190325","perf");
		// Map<String, String> map = api.getDocument("JIFZl7gO","loyaltyMailbox","txt","12314328",null,"20190322","prod");

		// Map<String, String> map = api.getDocument("JIFZl7gO","chargeback","txt","12589915",null,"20180404","prod");
		
		//Map<String, String> map = api.getDocument("JIFZl7gO","rfco","txt","12314328",null,"20190321","prod");
		// Map<String, String> map = api.getDocument("JIFZl7gO","allocation","csv","12314328",null,"20190321","prod");
		//Map<String, String> map = api.getDocument("JIFZl7gO","settlement","txt","12314329",null,"20190321","prod");
		// Map<String, String> map = api.getDocument("JIFZl7gO","mystery","csv","12589915",null,"20190321","prod");
		
		
		System.out.println(map.toString());
	}

}
