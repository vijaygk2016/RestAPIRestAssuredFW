package com.shell.apigee.poc;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;

import com.google.gson.Gson;

public class TestAPI {

	// Perf
	private static final String PERF_APIGEE_HOST = "api-dev.shell.com";
	private static final String PERF_APIGEE_PROTOCOL = "https";
	private static final String PERF_APIGEE_USER_NAME = "userdev";
	private static final String PERF_APIGEE_PASSWORD = "pwd123";
	private static final String PERF_APIGEE_API_KEY = "A4uBxDbVrexOKkcuNfNpx7p4o8Gn42N9";

	// Production
	private static final String PROD_APIGEE_HOST = "api.shell.com";
	private static final String PROD_APIGEE_PROTOCOL = "https";
	private static final String PROD_APIGEE_USER_NAME = "userprod";
	private static final String PROD_APIGEE_PASSWORD = "pwd@792";
	private static final String PROD_APIGEE_API_KEY = "Kk1vKkSxAJDykdjwUzS1q1psWLN3fa3F";

	private static final String APIGEE_DOC_API_URL = "ds-globalcommercial-markethub-doctype/webapi/da/v1/doctype/document";
	private static final String APIGEE_DOC_PRICE_API_URL = "ds-globalcommercial-markethub-doctype/webapi/da/v1/doctype/document-prices";
	private static final String APIGEE_TOKEN_API_URL = "ds-globalcommercial-markethub-doctype/webapi/da/v1/doctype/token";

	private static final String EMAIL_PROD_REST_URL = "http://microservices.markethub.prod.europe.shell.com:22180/emailengine/express-email";
	private static final String EMAIL_PERF_REST_URL = "http://microservices.markethub.perf.europe.shell.com:22180/emailengine/api-alert";

	private static final String NDF = "No documents found";

	private String generateTokenRequestXml(String providerKey) {
		StringBuffer sb = new StringBuffer();
		sb.append("<Request><ProviderKey>");
		sb.append(providerKey);
		sb.append("</ProviderKey></Request>");
		return sb.toString();
	}
	private String generateDocRequestJson(String docType, String outputFormat, String soldTo, String payer,
			String date) {
		Date dt = new Date();
		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMdd");
		Map<String, String> map = new HashMap<String, String>();
		map.put("documentType", docType);
		map.put("outputFormat", outputFormat);
				if (soldTo != null)
			map.put("soldTo", soldTo);
		else
			map.put("payerId", payer);
		map.put("dateRequested", "docAvail");
		if (date == null) {
			map.put("toDate", sf.format(dt));
			map.put("fromDate", sf.format(dt));
		} else {
			map.put("toDate", date);
			map.put("fromDate", date);
		}
		
		Gson gson = new Gson();
		return gson.toJson(map);
	}

	private String generateDocumentRequestXml(String providerKey, String token, String encData) {
		StringBuffer sb = new StringBuffer();
		sb.append("<Request><ProviderKey>");
		sb.append(providerKey);
		sb.append("</ProviderKey><Token>");
		sb.append(token);
		sb.append("</Token><RequestData>");
		sb.append(encData);
		sb.append("</RequestData></Request>");
		return sb.toString();
	}

	private ApigeeConnector getApigeeConnector(String env) {
		ApigeeConnector ac = null;
		if (env != null && env.equalsIgnoreCase("prod")) {
			ac = new ApigeeConnector(PROD_APIGEE_HOST, PROD_APIGEE_PROTOCOL, PROD_APIGEE_USER_NAME,
					PROD_APIGEE_PASSWORD, PROD_APIGEE_API_KEY);
		} else {
			ac = new ApigeeConnector(PERF_APIGEE_HOST, PERF_APIGEE_PROTOCOL, PERF_APIGEE_USER_NAME,
					PERF_APIGEE_PASSWORD, PERF_APIGEE_API_KEY);
		}
		return ac;
	}

	private void triggrAlertEmail(String docType, String env, String resp, String req) {
		StringBuilder sb = new StringBuilder();
		sb.append("API Failed for DocType " + docType + " in " + env + "\n");
		sb.append("\n Request JSON => " + req);
		sb.append("\n");
		sb.append(resp);
		sb.append("\n");
		HttpPost httpPost = null;
		if (env != null && env.equalsIgnoreCase("prod")) {
			httpPost = new HttpPost(EMAIL_PROD_REST_URL);
		} else {
			httpPost = new HttpPost(EMAIL_PERF_REST_URL);
		}
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		try {
			MultipartEntityBuilder builder = MultipartEntityBuilder.create()
					.setMode(HttpMultipartMode.BROWSER_COMPATIBLE)
					.addTextBody("to", "p.gurung@shell.com,fasiulla.d@shell.com,")
					.addTextBody("from", "API-Alerts@shell.com")
					.addTextBody("subject", "API Failed for DocType " + docType + " in " + env)
					.addTextBody("body", sb.toString());
			HttpEntity multiPartEntity = builder.build();
			// httpPost.setEntity(new UrlEncodedFormEntity(postParameters,
			// "UTF-8"));
			httpPost.setEntity(multiPartEntity);
			httpClient.execute(httpPost);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Map<String, String> getDocument(String providerKey, String docType, String outputFormat, String soldTo,String payer, String date, String env) {
		Map<String, String> respMap;
		String tokenReqXml = generateTokenRequestXml(providerKey);
		ApigeeConnector ac = getApigeeConnector(env);
		respMap = ac.post(APIGEE_TOKEN_API_URL, tokenReqXml);
		String tokenResp = respMap.get("ResponseContent");
		if (tokenResp != null && tokenResp.contains("<Token>")) {
			String reqData = generateDocRequestJson(docType, outputFormat, soldTo, payer, date);
			System.out.println(reqData);
			String encReqData = EncryptUtil.encrypt(reqData);
			String token = tokenResp.substring(tokenResp.indexOf("<Token>") + 7, tokenResp.indexOf("</Token>"));
			String docReqXml = generateDocumentRequestXml(providerKey, token, encReqData);

			if (!docType.toLowerCase().endsWith("price")) {
				respMap = ac.post(APIGEE_DOC_API_URL, docReqXml);
			} else {
				respMap = ac.post(APIGEE_DOC_PRICE_API_URL, docReqXml);
			}
			if (respMap.get("StatusCode") == null
					|| (!respMap.get("StatusCode").equals("200") && !respMap.get("StatusCode").equals("405"))) {
				String respContent = respMap.get("ResponseContent");
				if (respContent == null || ((respContent.contains("EDA5013") || respContent.contains("EDA5014")
						|| respContent.contains("EDA5002")) && !respContent.contains(NDF))) {
					triggrAlertEmail(docType, env, respMap.toString(), reqData);
				}
			}
		} else {
			triggrAlertEmail(docType, env, respMap.toString(), "TokenRequest Failed => " + tokenReqXml);
		}
		return respMap;
	}
	
	
}

